package com.complex;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Login {

	//**********  TEST CASE "Login is successful"***********************

	@Test
	public void SuccessfullLogin() throws IOException, InterruptedException

	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Test\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://api-demo.supplybrain.io/login");
		//getting data from excel i.e username and password
		String username = Util.readExcel(0, 0);
		
		String password = Util.readExcel(0, 1);
		dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		
		
		dr.findElement(By.id("email")).sendKeys(username); //sending username 
		dr.findElement(By.id("password")).sendKeys(password); //sending password
		
		dr.findElement(By.xpath("//button[@type='submit']")).click();//clicking on Login button
		

		WebDriverWait wait=new WebDriverWait(dr, 5);
		WebElement Message = dr.findElement(By.xpath("//*[@class='card-body']"));
		wait.until(ExpectedConditions.visibilityOf(Message));

		//VERIFICATION POINT 
		
		String actual = Message.getText();
		String expect = "You are logged in!";
		Assert.assertEquals(actual, expect);
		System.out.println(" Logged in Successfully");
		
		
		
		
		dr.close();
		dr.quit();

	}
	

}
