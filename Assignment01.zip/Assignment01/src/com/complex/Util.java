package com.complex;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
;



public class Util {
private static XSSFWorkbook xss;

public static String readExcel(int row1, int col1) throws IOException {
		
		File file = new File("C:\\Users\\Test\\Downloads\\Data.xlsx");
	    FileInputStream fis = new FileInputStream(file);//opening excel/loading
	    
	    xss = new XSSFWorkbook(fis);
	    XSSFSheet sheet= xss.getSheet("Sheet1");
	    
	    
		
	   return sheet.getRow(row1).getCell(col1).getStringCellValue();
	
	 
	    
		
		
	}  
}
