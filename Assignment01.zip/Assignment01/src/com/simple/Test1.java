package com.simple;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {

	
	public static void main(String[] args) throws InterruptedException {
		
		Login(); //calling the Login method in main method.
		
	}
	
	public static void Login() throws InterruptedException{
		
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Test\\Downloads\\chromedriver_win32\\chromedriver.exe"); //set property for chromedriver executable to support chrome browser
	
	WebDriver dr = new ChromeDriver(); // created an object for Webdriver
	dr.manage().window().maximize(); //maximize browser Window
	
	dr.get("https://api-demo.supplybrain.io/login"); // used to navigate to the url
	
	Thread.sleep(3000); // a small wait of 3 seconds so that page gets loaded correctly and we do not get NoSuchElementException
	
	dr.findElement(By.id("email")).sendKeys("njdemo@njtest.com"); //sending username 
	dr.findElement(By.id("password")).sendKeys("njdemo1234"); //sending password
	
	dr.findElement(By.xpath("//button[@type='submit']")).click();//clicking on Login button
	
	Thread.sleep(6000); //to wait till the Home page loads after logging in
	
	String L = dr.findElement(By.xpath("//*[@class='card-body']")).getText(); //This is used to get the message observed on the Home page which displays as "You are logged in!" 
	
	
	// this if condition confirms whether login was successful or not, After logging in, I have compared the messaged observed on Home page to confirm whether login was successful or not.
	if (L.contentEquals("You are logged in!")){
		
		System.out.println("Log In was successful");
	}
	 
	dr.close();// close the browser window
	
	dr.quit(); // quit the chrome driver gracefully.
	
	}
}
